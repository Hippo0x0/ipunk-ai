iPunk authored fixture for REA 6.10.1 static CLI checks.
Use a supported Node runtime; the recorded runtime is 22.23.4.
The complete commands and scope are on https://ai.ipunk.cn/en/projects/rea/#javascript-test
verify-rea-fixture.py checks REA JSON; verify-truth.mjs checks the authored source separately.
