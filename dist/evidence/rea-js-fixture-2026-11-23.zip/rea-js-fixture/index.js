import { total } from './lib/price.js';
import { loadPlugin } from './lib/plugin.js';
export function invoice(unitPrice, quantity, discount = 0) {
  return { total: total(unitPrice, quantity, discount), currency: 'USD' };
}
export { loadPlugin };
