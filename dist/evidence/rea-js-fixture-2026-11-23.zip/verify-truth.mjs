import assert from 'node:assert/strict';
import {invoice} from './rea-js-fixture/index.js';
assert.deepEqual(invoice(20,3,.1), {total:54,currency:'USD'});
assert.deepEqual(invoice(5,2), {total:10,currency:'USD'});
console.log('Fixture truth check passed: two expected invoice results; no dynamic plugin invoked.');
